1. Open the "Eclipse" folder on the desktop
2. Start the eclipse application by double-clicking the eclipse icon
3. The test project gets loaded from the workspace to demonstrate the usage of "aPET" tool
4. Select ABS perspective by navigating to "Window-> Open Perspective -> Other"
5. Open the Factorial.abs file from the testProject 
6. Select calculate method from "Class A" from the outline on the right hand side.
7. Press "Ctrl + 8" or go to "Apet -> Generate test-cases with aPET" 
8. Configure the options or select the default options and proceed.
9. Test cases will be generated in the form of text output in the console window.
10. Generated test cases can also be found at :/tmp/pet/abs_testcases.xml
11.To view the demo, click on YoutubeDemo file on desktop or visit https://youtu.be/1M_-Nk65D34
